import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import ChatPanel from '@/pages/ChatPanel';
import FixHistory from '@/pages/FixHistory';
import Subscription from '@/pages/Subscription';
import Customers from '@/pages/Customers';
import KnowledgeBase from '@/pages/KnowledgeBase';
import PluginDownload from '@/pages/PluginDownload';
import VulnerabilityScans from '@/pages/VulnerabilityScans';
import SiteAuditLog from '@/pages/SiteAuditLog';
import Notifications from '@/pages/Notifications';
import StagedFixes from '@/pages/StagedFixes';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/chat" element={<ChatPanel />} />
        <Route path="/fix-history" element={<FixHistory />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/customers" element={<Customers />} />
        <Route path="/knowledge-base" element={<KnowledgeBase />} />
        <Route path="/plugin-download" element={<PluginDownload />} />
        <Route path="/vulnerability-scans" element={<VulnerabilityScans />} />
        <Route path="/audit-log" element={<SiteAuditLog />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/staged-fixes" element={<StagedFixes />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App